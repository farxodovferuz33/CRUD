export default function Page404(){
    return (
        <div style={{backgroundColor:"grey"}}>
            <h1 style={{textAlign:"center"}}>404 PAGE NOT FOUND</h1>
            <img style={{width:"1520px"}} src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcShzym7c8WmdaC931Bhk-5w-HGf8_W7VDPqBQOjfctDgtbiTjDWvb1iAOg-qJEgLIRGlTo&usqp=CAU" alt="404" />
        </div>
    )
}